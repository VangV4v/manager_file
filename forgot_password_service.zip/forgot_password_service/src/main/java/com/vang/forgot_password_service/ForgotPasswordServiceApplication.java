package com.vang.forgot_password_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForgotPasswordServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForgotPasswordServiceApplication.class, args);
	}

}
