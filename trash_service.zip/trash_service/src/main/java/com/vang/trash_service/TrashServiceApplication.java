package com.vang.trash_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrashServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrashServiceApplication.class, args);
	}

}
