package com.vang.trash_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrashServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
